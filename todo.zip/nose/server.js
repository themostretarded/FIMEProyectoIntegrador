const mongo = require('mongoose');
const aplicacion = require('express');

var Schema = mongo.Schema;
/*var extraccion = new Schema({
  nombres:  [{nombre:String}]
});*/
var silbato = new Schema({
	can : String
	});
//var modelo = mongo.model('losnombres', extraccion,"losnombres");
var modelosilbato = mongo.model('caninos',silbato,"caninos");

mongo.connect("mongodb://localhost/nombres/");
let conn = mongo.connection;
modelosilbato.find({})
.then(res => {
	console.log(res);
})

// respond with "hello world" when a GET request is made to the homepage
aplicacion.get('/', function(req, res) {
  res.send('hello world');
  res.sendFile(__dirname + '/index.html')
});