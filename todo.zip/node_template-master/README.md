FORMAT: v0.0.1

# <NAME APP>

Backend de la aplicacion de <NAME APP>.

El módulo de <NAME APP> se encarga principalmente de ...

# Starting Comands
```
npm install
```

```
node server.js
```


## Librerías Mandatorias

Checar el package.json, las librerías a resaltar son:

    npm install axios
    ...

El proyecto, se divide en dos archivos principales: server.js & <...>

## Server.js
Este es el encargado de levantar el servidor y tener las rutas disponibles para su consum


### Providers [GET]

##### Route: [GET]'/'

 + Response 200 (application/json)

		{
      ...
    }
        
#### Params

 + {}: 

