// Extern Libraries 
// ...

// My Libraries 
const Utils = require('./../core/utils/Utils')

// Constants
// ...


// --------------------------------------------
// -----------------MODELS---------------------
// --------------------------------------------

let Model = () => {

}


module.exports = {
	Model
}